#ifndef BUTTON_READER_H
#define BUTTON_READER_H

void* readButtonFIFO(void* arg);  // 버튼 IPC FIFO 읽기 쓰레드 함수

#endif // BUTTON_READER_H


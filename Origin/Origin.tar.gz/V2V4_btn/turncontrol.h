#ifndef TURNCONTROL_H
#define TURNCONTROL_H

// 함수 선언만 남겨둡니다:
void endTurn();
void continueTurn();
void checkStation();
void checkScore();
void checkWin();

#endif //
